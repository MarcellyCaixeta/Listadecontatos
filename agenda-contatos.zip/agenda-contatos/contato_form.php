<?php
require 'config.php';
exigir_login();

$uid = $_SESSION['usuario_id'];
$id  = (int) ($_GET['id'] ?? $_POST['id'] ?? 0);
$erros = [];
$c = ['nome' => '', 'telefone' => '', 'email' => '', 'endereco' => '', 'observacoes' => ''];

// Edição: carrega o contato (somente se pertencer ao usuário logado)
if ($id > 0 && $_SERVER['REQUEST_METHOD'] !== 'POST') {
    $stmt = $conn->prepare(
        'SELECT nome, telefone, email, endereco, observacoes
         FROM contatos WHERE id = ? AND usuario_id = ?'
    );
    $stmt->bind_param('ii', $id, $uid);
    $stmt->execute();
    $encontrado = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if (!$encontrado) {
        $_SESSION['flash'] = 'Contato não encontrado.';
        redirecionar('index.php');
    }
    $c = $encontrado;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_validar();

    foreach (['nome', 'telefone', 'email', 'endereco', 'observacoes'] as $campo) {
        $c[$campo] = trim($_POST[$campo] ?? '');
    }

    if ($c['nome'] === '' || mb_strlen($c['nome']) > 100) {
        $erros[] = 'Informe o nome (até 100 caracteres).';
    }
    if (!preg_match('/^[0-9()+\-\s]{8,20}$/', $c['telefone'])) {
        $erros[] = 'Informe um telefone válido (apenas números, espaços, +, - e parênteses).';
    }
    if ($c['email'] !== '' && !filter_var($c['email'], FILTER_VALIDATE_EMAIL)) {
        $erros[] = 'E-mail do contato inválido.';
    }

    if (!$erros) {
        // Campos opcionais vazios viram NULL
        $email = $c['email'] !== '' ? $c['email'] : null;
        $end   = $c['endereco'] !== '' ? $c['endereco'] : null;
        $obs   = $c['observacoes'] !== '' ? $c['observacoes'] : null;

        if ($id > 0) {
            $stmt = $conn->prepare(
                'UPDATE contatos SET nome = ?, telefone = ?, email = ?, endereco = ?, observacoes = ?
                 WHERE id = ? AND usuario_id = ?'
            );
            $stmt->bind_param('sssssii', $c['nome'], $c['telefone'], $email, $end, $obs, $id, $uid);
        } else {
            $stmt = $conn->prepare(
                'INSERT INTO contatos (usuario_id, nome, telefone, email, endereco, observacoes)
                 VALUES (?, ?, ?, ?, ?, ?)'
            );
            $stmt->bind_param('isssss', $uid, $c['nome'], $c['telefone'], $email, $end, $obs);
        }

        if ($stmt->execute()) {
            $stmt->close();
            $_SESSION['flash'] = $id > 0 ? 'Contato atualizado.' : 'Contato adicionado.';
            redirecionar('index.php');
        }
        $erros[] = 'Erro ao salvar o contato.';
        $stmt->close();
    }
}

$titulo = $id > 0 ? 'Editar contato' : 'Novo contato';
include 'header.php';
?>
<section class="card estreito">
  <h2><?= e($titulo) ?></h2>

  <?php foreach ($erros as $erro): ?>
    <p class="alerta erro"><?= e($erro) ?></p>
  <?php endforeach; ?>

  <form method="post">
    <?= csrf_campo() ?>
    <input type="hidden" name="id" value="<?= $id ?>">

    <label for="nome">Nome *</label>
    <input type="text" id="nome" name="nome" value="<?= e($c['nome']) ?>" required>

    <label for="telefone">Telefone *</label>
    <input type="tel" id="telefone" name="telefone" value="<?= e($c['telefone']) ?>" required>

    <label for="email">E-mail</label>
    <input type="email" id="email" name="email" value="<?= e($c['email']) ?>">

    <label for="endereco">Endereço</label>
    <input type="text" id="endereco" name="endereco" value="<?= e($c['endereco']) ?>">

    <label for="observacoes">Observações</label>
    <textarea id="observacoes" name="observacoes" rows="3"><?= e($c['observacoes']) ?></textarea>

    <button type="submit">Salvar</button>
    <a href="index.php">Cancelar</a>
  </form>
</section>
<?php include 'footer.php'; ?>
