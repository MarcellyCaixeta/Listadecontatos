<?php
require 'config.php';

if (esta_logado()) {
    redirecionar('index.php');
}

$erros = [];
$nome = $email = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_validar();

    $nome      = trim($_POST['nome'] ?? '');
    $email     = trim($_POST['email'] ?? '');
    $senha     = $_POST['senha'] ?? '';
    $confirmar = $_POST['confirmar'] ?? '';

    if ($nome === '' || mb_strlen($nome) > 100) {
        $erros[] = 'Informe um nome válido (até 100 caracteres).';
    }
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $erros[] = 'Informe um e-mail válido.';
    }
    if (strlen($senha) < 8) {
        $erros[] = 'A senha deve ter pelo menos 8 caracteres.';
    }
    if ($senha !== $confirmar) {
        $erros[] = 'A confirmação não confere com a senha.';
    }

    if (!$erros) {
        // E-mail já cadastrado?
        $stmt = $conn->prepare('SELECT id FROM usuarios WHERE email = ?');
        $stmt->bind_param('s', $email);
        $stmt->execute();
        $stmt->store_result();
        $existe = $stmt->num_rows > 0;
        $stmt->close();

        if ($existe) {
            $erros[] = 'Este e-mail já está cadastrado.';
        } else {
            $hash = password_hash($senha, PASSWORD_DEFAULT);
            $stmt = $conn->prepare('INSERT INTO usuarios (nome, email, senha_hash) VALUES (?, ?, ?)');
            $stmt->bind_param('sss', $nome, $email, $hash);
            if ($stmt->execute()) {
                $stmt->close();
                $_SESSION['flash'] = 'Cadastro realizado! Faça login.';
                redirecionar('login.php');
            }
            $erros[] = 'Erro ao cadastrar. Tente novamente.';
            $stmt->close();
        }
    }
}

$titulo = 'Criar conta';
include 'header.php';
?>
<section class="card estreito">
  <h2>Criar conta</h2>

  <?php foreach ($erros as $erro): ?>
    <p class="alerta erro"><?= e($erro) ?></p>
  <?php endforeach; ?>

  <form method="post" novalidate>
    <?= csrf_campo() ?>

    <label for="nome">Nome</label>
    <input type="text" id="nome" name="nome" value="<?= e($nome) ?>" required>

    <label for="email">E-mail</label>
    <input type="email" id="email" name="email" value="<?= e($email) ?>" required>

    <label for="senha">Senha (mín. 8 caracteres)</label>
    <input type="password" id="senha" name="senha" required>

    <label for="confirmar">Confirmar senha</label>
    <input type="password" id="confirmar" name="confirmar" required>

    <button type="submit">Cadastrar</button>
  </form>
  <p>Já tem conta? <a href="login.php">Entrar</a></p>
</section>
<?php include 'footer.php'; ?>
