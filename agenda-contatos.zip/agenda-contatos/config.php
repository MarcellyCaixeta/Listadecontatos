<?php
declare(strict_types=1);

session_start();

// ---- Conexão (ajuste conforme seu ambiente) ----
const DB_HOST = 'localhost';
const DB_USER = 'root';
const DB_PASS = '';
const DB_NAME = 'agenda_contatos';

mysqli_report(MYSQLI_REPORT_OFF);
$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
if ($conn->connect_errno) {
    die('Erro ao conectar ao banco de dados: ' . $conn->connect_error);
}
$conn->set_charset('utf8mb4');

// ---- Funções auxiliares ----

/** Escapa texto para exibir em HTML (evita XSS). */
function e(?string $texto): string
{
    return htmlspecialchars($texto ?? '', ENT_QUOTES, 'UTF-8');
}

/** Token CSRF da sessão. */
function csrf_token(): string
{
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf'];
}

function csrf_campo(): string
{
    return '<input type="hidden" name="csrf" value="' . csrf_token() . '">';
}

/** Interrompe a requisição se o token CSRF for inválido. */
function csrf_validar(): void
{
    $enviado = $_POST['csrf'] ?? '';
    if (!hash_equals($_SESSION['csrf'] ?? '', $enviado)) {
        http_response_code(403);
        die('Requisição inválida (CSRF).');
    }
}

function esta_logado(): bool
{
    return isset($_SESSION['usuario_id']);
}

/** Redireciona para o login se não houver sessão. */
function exigir_login(): void
{
    if (!esta_logado()) {
        header('Location: login.php');
        exit;
    }
}

function redirecionar(string $url): void
{
    header('Location: ' . $url);
    exit;
}
