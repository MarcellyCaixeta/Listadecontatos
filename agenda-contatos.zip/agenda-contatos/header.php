<?php /* Uso: defina $titulo antes de incluir */ ?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title><?= e($titulo ?? 'Agenda de Contatos') ?></title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
<header class="topo">
  <h1>📒 Agenda de Contatos</h1>
  <?php if (esta_logado()): ?>
    <nav>
      <span>Olá, <?= e($_SESSION['usuario_nome']) ?></span>
      <a href="index.php">Contatos</a>
      <a href="contato_form.php">Novo contato</a>
      <a href="logout.php">Sair</a>
    </nav>
  <?php endif; ?>
</header>
<main class="container">
