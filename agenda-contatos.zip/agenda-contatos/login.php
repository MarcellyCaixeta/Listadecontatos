<?php
require 'config.php';

if (esta_logado()) {
    redirecionar('index.php');
}

$erro = '';
$email = '';
$flash = $_SESSION['flash'] ?? '';
unset($_SESSION['flash']);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_validar();

    $email = trim($_POST['email'] ?? '');
    $senha = $_POST['senha'] ?? '';

    $stmt = $conn->prepare('SELECT id, nome, senha_hash FROM usuarios WHERE email = ?');
    $stmt->bind_param('s', $email);
    $stmt->execute();
    $usuario = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    // Mensagem genérica: não revela se o e-mail existe
    if ($usuario && password_verify($senha, $usuario['senha_hash'])) {
        session_regenerate_id(true); // evita fixação de sessão
        $_SESSION['usuario_id']   = (int) $usuario['id'];
        $_SESSION['usuario_nome'] = $usuario['nome'];
        redirecionar('index.php');
    }
    $erro = 'E-mail ou senha incorretos.';
}

$titulo = 'Entrar';
include 'header.php';
?>
<section class="card estreito">
  <h2>Entrar</h2>

  <?php if ($flash): ?><p class="alerta ok"><?= e($flash) ?></p><?php endif; ?>
  <?php if ($erro): ?><p class="alerta erro"><?= e($erro) ?></p><?php endif; ?>

  <form method="post">
    <?= csrf_campo() ?>

    <label for="email">E-mail</label>
    <input type="email" id="email" name="email" value="<?= e($email) ?>" required>

    <label for="senha">Senha</label>
    <input type="password" id="senha" name="senha" required>

    <button type="submit">Entrar</button>
  </form>
  <p>Ainda não tem conta? <a href="register.php">Cadastre-se</a></p>
</section>
<?php include 'footer.php'; ?>
