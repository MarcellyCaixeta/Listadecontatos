# Agenda de Contatos (PHP + MySQLi)

## Como rodar
1. Instale o XAMPP (ou outro ambiente com PHP 8+ e MySQL/MariaDB).
2. Copie a pasta `agenda-contatos` para `htdocs`.
3. No phpMyAdmin, importe o arquivo `database.sql`.
4. Ajuste usuário/senha do banco em `config.php`, se necessário.
5. Acesse http://localhost/agenda-contatos/register.php, crie sua conta e faça login.

## Arquivos
- `config.php`: conexão MySQLi (orientada a objetos), sessão e funções auxiliares (e(), CSRF, exigir_login)
- `register.php` / `login.php` / `logout.php`: autenticação
- `index.php`: listagem e busca de contatos (LIKE)
- `contato_form.php`: cadastro e edição
- `delete.php`: exclusão (somente via POST)

## Segurança aplicada
- Prepared Statements em todas as consultas (contra SQL Injection)
- Senhas com password_hash() / password_verify()
- session_regenerate_id() no login (contra fixação de sessão)
- Token CSRF em todos os formulários POST
- htmlspecialchars() em toda saída (contra XSS)
- Cada usuário só enxerga e altera os próprios contatos (filtro por usuario_id)
