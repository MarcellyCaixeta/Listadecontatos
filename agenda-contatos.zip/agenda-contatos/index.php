<?php
require 'config.php';
exigir_login();

$uid = $_SESSION['usuario_id'];
$q   = trim($_GET['q'] ?? '');
$flash = $_SESSION['flash'] ?? '';
unset($_SESSION['flash']);

if ($q !== '') {
    $like = '%' . $q . '%';
    $stmt = $conn->prepare(
        'SELECT id, nome, telefone, email, endereco FROM contatos
         WHERE usuario_id = ? AND (nome LIKE ? OR telefone LIKE ? OR email LIKE ?)
         ORDER BY nome'
    );
    $stmt->bind_param('isss', $uid, $like, $like, $like);
} else {
    $stmt = $conn->prepare(
        'SELECT id, nome, telefone, email, endereco FROM contatos
         WHERE usuario_id = ? ORDER BY nome'
    );
    $stmt->bind_param('i', $uid);
}
$stmt->execute();
$contatos = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

$titulo = 'Meus contatos';
include 'header.php';
?>
<section class="card">
  <h2>Meus contatos (<?= count($contatos) ?>)</h2>

  <?php if ($flash): ?><p class="alerta ok"><?= e($flash) ?></p><?php endif; ?>

  <form method="get" class="busca">
    <label for="q" class="oculto">Buscar</label>
    <input type="text" id="q" name="q" value="<?= e($q) ?>" placeholder="Buscar por nome, telefone ou e-mail">
    <button type="submit">Buscar</button>
    <?php if ($q !== ''): ?><a href="index.php">Limpar</a><?php endif; ?>
  </form>

  <?php if (!$contatos): ?>
    <p>Nenhum contato encontrado. <a href="contato_form.php">Adicionar o primeiro</a>.</p>
  <?php else: ?>
    <div class="tabela-wrap">
    <table>
      <thead>
        <tr><th>Nome</th><th>Telefone</th><th>E-mail</th><th>Endereço</th><th>Ações</th></tr>
      </thead>
      <tbody>
      <?php foreach ($contatos as $c): ?>
        <tr>
          <td><?= e($c['nome']) ?></td>
          <td><?= e($c['telefone']) ?></td>
          <td><?= e($c['email']) ?></td>
          <td><?= e($c['endereco']) ?></td>
          <td class="acoes">
            <a href="contato_form.php?id=<?= (int) $c['id'] ?>">Editar</a>
            <form method="post" action="delete.php"
                  onsubmit="return confirm('Excluir este contato?');">
              <?= csrf_campo() ?>
              <input type="hidden" name="id" value="<?= (int) $c['id'] ?>">
              <button type="submit" class="perigo">Excluir</button>
            </form>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
    </div>
  <?php endif; ?>
</section>
<?php include 'footer.php'; ?>
