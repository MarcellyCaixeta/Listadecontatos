<?php
require 'config.php';
exigir_login();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirecionar('index.php');
}
csrf_validar();

$id  = (int) ($_POST['id'] ?? 0);
$uid = $_SESSION['usuario_id'];

$stmt = $conn->prepare('DELETE FROM contatos WHERE id = ? AND usuario_id = ?');
$stmt->bind_param('ii', $id, $uid);
$stmt->execute();
$ok = $stmt->affected_rows > 0;
$stmt->close();

$_SESSION['flash'] = $ok ? 'Contato excluído.' : 'Contato não encontrado.';
redirecionar('index.php');
